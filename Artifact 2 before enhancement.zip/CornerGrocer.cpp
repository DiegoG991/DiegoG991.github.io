//Diego Garcia
//4-20-2025
//project 3
#include <iostream>
#include <fstream>
#include <cstdlib>
#include "CornerGrocer.h"
using namespace std;

//Constructor
CornerGrocer::CornerGrocer(){ 

}

void CornerGrocer::DisplayMenu() {
	//Display menu options
	cout << "Menu Options:" << endl;
	cout << "1. Search for an item" << endl;
	cout << "2. Get item frequency" << endl;
	cout << "3. Print item frequency histogram" << endl;
	cout << "4. Exit program" << endl;
}

void CornerGrocer::SearchItem() {
	//Search for item that user wants
	string item; 
	cout << "Enter the item to search: ";
	cin >> item;

	
	if (cornerGrocer.count(item)) {
		//searching for an item in the map
		cout << "Frequency of " << item << " is " << cornerGrocer[item] << endl;
	}
	else {
		cout << item << " not found" << endl;
	}
}

//finding item frequency
void CornerGrocer::PrintFrequencyList() {
	//goes through the map and then prints the frequencies
	for (auto pair : cornerGrocer) {
		cout << endl;
		cout << pair.first << " " << pair.second << endl;
	}
}
//Print freuquency using *
void CornerGrocer::PrintFrequencyHistogram() {
	for (auto pair : cornerGrocer) {
		//goes through map and prints frequency using *
		cout << pair.first << " ";
		for (int i = 0; i < pair.second; ++i) {
			cout << "*";
		}
		cout << endl;
	}
}
//save the data to a different file
void CornerGrocer::SaveFile() {
	//open the file
	ofstream outFile(outputFileName);
	
	//writes the data into the file
	for (auto pair : cornerGrocer) {
		outFile << pair.first << " " << pair.second << endl;
	}
	outFile.close(); //close file
}


void CornerGrocer::LoadFile() {
	//open the text file
	ifstream inputFile(inputFileName);
	
	string item;
	if (inputFile.is_open()) {
		//if file opens then print file open
		cout << "file open" << endl;
	}
	else {
		//if file don't open then print file not open
		cout << "File not open" << endl;
	}
	//Counts how many times item appears in the file
	while (inputFile >> item) {
		cornerGrocer[item]++;
	}
	inputFile.close();
}