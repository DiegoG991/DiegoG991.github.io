//Diego Garcia
//4-20-2025
//project 3
#include "CornerGrocer.h"
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    CornerGrocer grocer; // create grocer instance
    grocer.LoadFile(); //open the file
    
    int userInput; //set user input to 1 so loop starts
    userInput = 1;
    
    //while loop so program does not end unless user enters 4
    while (userInput != 4) {
        grocer.DisplayMenu();
        cout << "Enter input: ";
        cin >> userInput;

        //switch case for input
        switch (userInput) {
        case 1: 
            //if 1 then search for the item
            grocer.SearchItem();
            break;
        
        case 2: 
            //if 2 then print the frequency list
            grocer.PrintFrequencyList();
            break;
        
        case 3: 
            //if 3 then print histogram
            grocer.PrintFrequencyHistogram();
            break;
        
        case 4: 
            //if 4 then exit program
            cout << "Exited program" << endl;
            break;

        default:
            //if not 1-4 then not a valid choice
            cout << "Not valid choice" << endl;
            break;
            
       }

        

       
    }
    //print data to backup file
    grocer.SaveFile();
    return 0;
}

