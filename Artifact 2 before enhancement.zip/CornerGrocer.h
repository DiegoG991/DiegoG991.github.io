//Diego Garcia
//4-20-2025
//project 3
#pragma once
#ifndef CornerGrocer_h
#define CornerGrocer_h



#include <iostream>
#include <string>
#include <map>


using namespace std;
//create Cornergrocer class
class CornerGrocer {
public:
	//functions for class
	CornerGrocer();
	void DisplayMenu();
	void SearchItem();
	void PrintFrequencyList();
	void PrintFrequencyHistogram();
	void SaveFile();
	void LoadFile();

private:
	//variables for class
	map<string, int> cornerGrocer;
	string inputFileName = "CS210_Project_Three_Input_File.txt";
	string outputFileName = "frequency.dat";


};
#endif